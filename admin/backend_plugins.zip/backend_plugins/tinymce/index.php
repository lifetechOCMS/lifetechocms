	    
        
    <?php  
 echo'<script>window.location= "../index.php";</script>';	
 
?>
    
