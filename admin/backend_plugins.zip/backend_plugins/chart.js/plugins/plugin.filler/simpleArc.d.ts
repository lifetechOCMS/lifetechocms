export class simpleArc {
    constructor(opts: any);
    x: any;
    y: any;
    radius: any;
    pathSegment(ctx: any, bounds: any, opts: any): boolean;
    interpolate(point: any): {
        x: any;
        y: any;
        angle: any;
    };
}
