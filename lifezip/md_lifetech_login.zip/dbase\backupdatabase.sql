-- PHP MySQL Dump
--
-- Host: 
-- Generated: Wed, 14 Aug 2024 16:47:25 +0200
-- PHP Version: 8.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";;;;;_lifetechend;;;;;

--
-- Database: `lifetechocms`
--
